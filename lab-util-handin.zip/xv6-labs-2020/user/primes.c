#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"


void get_prime(int p[2]){


	int prime,n;
	int p1[2];

	
	
	if (read(p[0],&prime,4)!=0){
		printf("prime %d\n",prime);	
		
	}
	else{
	exit(0);
	
	}
	
	pipe(p1);
	
	
	if (fork()==0){
		close(p1[1]);
		get_prime(p1);
	
	}
	
	else{
		close(p1[0]);
		while(read(p[0],&n,4)!=0){
			if(n % prime !=0){
				write(p1[1],&n,4);	
			
			}	
		
		}
		close(p1[1]);
		wait(0);
		exit(0);
	}
	
	
	



}





int
main(int argc, char *argv[]){

	int p[2];
	pipe(p);

	
	if (fork()==0){
		close(p[1]);
		get_prime(p);
	}
	else{
		for(int n =2 ;n <=35;n++){
			close(p[0]);
			write(p[1],&n,4);
		}
		close(p[1]);
		wait(0);

	}
	exit(0);
}
